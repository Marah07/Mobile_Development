package essect.td1_grp3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Poids extends AppCompatActivity {

    private Button BPI;
    private int taille, poidsIdeal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calcul_poids);

        BPI = (Button)findViewById(R.id.poidsBtn);

BPI.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
       EditText Taille = (EditText)findViewById(R.id.Taille);

       taille = Integer.parseInt(Taille.getText().toString());

       poidsIdeal = (taille*3-250)/4 ;

        Toast.makeText(Poids.this,"Votre poids idéal est: "+poidsIdeal,Toast.LENGTH_SHORT).show();

    }
});
    }
}